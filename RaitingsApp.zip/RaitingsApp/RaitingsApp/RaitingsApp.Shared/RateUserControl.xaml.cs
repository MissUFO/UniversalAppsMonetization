﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives; 
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

namespace RaitingsApp
{
    public sealed partial class RateUserControl : UserControl
    {
        static private string REVIEW_TEXT = "Надеемся, вам нравится наше приложение. Пожалуйста, оцените его.";
        static private string REVIEW_INVITE_TEXT = "Оценить";
        static private string REVIEW_DECLINE_TEXT = "Напомнить позже";

        private ApplicationDataCompositeValue status;

        public RateUserControl()
        {
            this.InitializeComponent();
            this.LoadReviewStatus();
            CheckReviewsAsync();
        }

        private void LoadReviewStatus()
        {
            var roamingSettings = ApplicationData.Current.RoamingSettings;
            var reviewStatus = (ApplicationDataCompositeValue)roamingSettings.Values["reviewStatus"];

            if (reviewStatus == null)
            {
                reviewStatus = new ApplicationDataCompositeValue();
                reviewStatus["userReviewedApp"] = false;
                reviewStatus["userReviewAppLaunches"] = 0;
            }

            this.status = reviewStatus;
        }

        private void SaveReviewStatus()
        {
            var roamingSettings = ApplicationData.Current.RoamingSettings;
            roamingSettings.Values["reviewStatus"] = this.status;

        }

        public async void CheckReviewsAsync()
        {
            if (this.status == null)
            {
                this.LoadReviewStatus();
            }

            var reviewed = (bool)this.status["userReviewedApp"];
            var launches = (int)this.status["userReviewAppLaunches"];

            if (!reviewed)
            {
                await this.AskForReviewAsync();
            }

            this.status["userReviewAppLaunches"] = ++launches;
            this.SaveReviewStatus();
        }

        private async Task AskForReviewAsync()
        {
            var messageDialog = new Windows.UI.Popups.MessageDialog(REVIEW_TEXT);

            messageDialog.Commands.Add(new Windows.UI.Popups.UICommand(REVIEW_INVITE_TEXT,
                async (action) =>
                {
                    var uri = new Uri("ms-windows-store:Review?pfn=Microsoft.SkypeApp_kzf8qxf38zg5c");
                    await Windows.System.Launcher.LaunchUriAsync(uri);

                    this.status["userReviewedApp"] = true;
                    this.SaveReviewStatus();
                }
                ));

            messageDialog.Commands.Add(new Windows.UI.Popups.UICommand(REVIEW_DECLINE_TEXT, null));

            messageDialog.DefaultCommandIndex = 0;
            messageDialog.CancelCommandIndex = 1;

            await messageDialog.ShowAsync();
        }

    }
}
