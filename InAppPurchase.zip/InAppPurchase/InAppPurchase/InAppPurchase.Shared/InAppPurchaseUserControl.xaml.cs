﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using Windows.ApplicationModel.Store;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

using Store = Windows.ApplicationModel.Store.CurrentAppSimulator;

namespace InAppPurchase
{
    public sealed partial class InAppPurchaseUserControl : UserControl
    {
        int m_pointCount = 0;

        public InAppPurchaseUserControl()
        {
            this.InitializeComponent();
        }

        async private void btnBuy50Points_Click(object sender, RoutedEventArgs e)
        {
            var file = await Windows.ApplicationModel.Package.Current.InstalledLocation.GetFileAsync("Data\\license.xml");
            await Store.ReloadSimulatorAsync(file);

            var listing = await Store.LoadListingInformationAsync();

            var fiftypoints = listing.ProductListings.FirstOrDefault(p => p.Value.ProductId == "feature1");

            try
            {
                await Store.RequestProductPurchaseAsync(fiftypoints.Value.ProductId);

                if (Store.LicenseInformation.ProductLicenses[fiftypoints.Value.ProductId].IsActive)
                {
                    try
                    {
                        await Store.GetProductReceiptAsync(fiftypoints.Value.ProductId);
                    }
                    catch { }

                    m_pointCount += 50;
                    txtBought50Pts.Visibility = Visibility.Visible;
                    txtBought50Pts.Text = "Вы купили еще 50 золотых монет. Итого у вас: " + m_pointCount + " золотых монет!";
                }
            }
            catch (Exception ex)
            {
                ShowMessageBox("Ошибка", ex.ToString());
            }
        }
        private async void ShowMessageBox(string title, string content)
        {
            var dialog = new MessageDialog(content);
            dialog.Title = title;
            await dialog.ShowAsync();
        } 
    }
}
